## Getting Started

First, run the database:

./pocketbase serve

Then, start the development server:

npm run dev